'use strict';

let SOMEXPL_1 = 0;
let SOMEXPL_2 = 0;
let SOMEXPL_3 = 0;
let SOMEXPL_4 = 0;
let SOMEXPL_5 = 0;